package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.ZomoCyan
import com.example.ui.theme.ZomoMintLight

/**
 * Ana sayfanın en üstündeki 3D cam efektli "hero" çerçevesi.
 * Katmanlar: derin mor degrade + neon ışık küreleri + bombeli cam parlaması +
 * kayan ışık huzmesi + renkli (iridescent) kenar + iç oyuk kenar.
 */
@Composable
fun GlassHeroBanner(
    hasGroup: Boolean,
    groupLabel: String,
    time: String,
    title: String,
    subtitle: String,
    badge: String,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(32.dp)
    val transition = rememberInfiniteTransition(label = "hero_shine")
    val shine by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 4200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shine"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .shadow(
                elevation = 22.dp,
                shape = shape,
                ambientColor = Color(0x667C3AED),
                spotColor = Color(0x998B5CF6)
            )
            .clip(shape)
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFF8B5CF6), Color(0xFF6D28D9), Color(0xFF3B1A8C))
                )
            )
            .drawBehind {
                val w = size.width
                val h = size.height

                // Neon ışık küreleri (derinlik hissi)
                val cyanCenter = Offset(w * 0.95f, h * 0.05f)
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(Color(0xFF22D3EE).copy(alpha = 0.55f), Color.Transparent),
                        center = cyanCenter,
                        radius = w * 0.55f
                    ),
                    radius = w * 0.55f,
                    center = cyanCenter
                )
                val pinkCenter = Offset(w * 0.02f, h * 1.0f)
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(Color(0xFFF472B6).copy(alpha = 0.45f), Color.Transparent),
                        center = pinkCenter,
                        radius = w * 0.5f
                    ),
                    radius = w * 0.5f,
                    center = pinkCenter
                )

                // Bombeli cam parlaması (üst yarı)
                drawRect(
                    brush = Brush.verticalGradient(
                        listOf(
                            Color.White.copy(alpha = 0.32f),
                            Color.White.copy(alpha = 0.07f),
                            Color.Transparent
                        ),
                        startY = 0f,
                        endY = h * 0.58f
                    ),
                    size = Size(w, h * 0.58f)
                )

                // Kayan ışık huzmesi
                val bandW = w * 0.32f
                val x = -bandW + shine * (w + bandW * 2f)
                drawRect(
                    brush = Brush.linearGradient(
                        listOf(Color.Transparent, Color.White.copy(alpha = 0.24f), Color.Transparent),
                        start = Offset(x, 0f),
                        end = Offset(x + bandW, h * 0.7f)
                    )
                )
            }
            // Dış parlak kenar (iridescent)
            .border(
                1.8.dp,
                Brush.linearGradient(
                    listOf(
                        Color.White.copy(alpha = 0.95f),
                        Color(0xFF67E8F9).copy(alpha = 0.85f),
                        Color(0xFFF0ABFC).copy(alpha = 0.85f),
                        Color.White.copy(alpha = 0.55f)
                    )
                ),
                shape
            )
            .padding(4.dp)
            // İç oyuk kenar (bevel)
            .border(1.dp, Color.White.copy(alpha = 0.16f), RoundedCornerShape(28.dp))
            .padding(horizontal = 16.dp, vertical = 16.dp)
            .testTag("hero_banner")
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 3D cam kupa karosu
                Box(
                    modifier = Modifier
                        .shadow(8.dp, RoundedCornerShape(18.dp), ambientColor = Color(0x66000000), spotColor = Color(0x66000000))
                        .size(58.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.White.copy(alpha = 0.42f), Color.White.copy(alpha = 0.10f))
                            )
                        )
                        .border(
                            1.2.dp,
                            Brush.verticalGradient(
                                listOf(Color.White.copy(alpha = 0.95f), Color.White.copy(alpha = 0.2f))
                            ),
                            RoundedCornerShape(18.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.btn_trophy),
                        contentDescription = null,
                        modifier = Modifier.size(46.dp),
                        contentScale = ContentScale.Fit
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column(modifier = Modifier.weight(1f)) {
                    if (hasGroup) {
                        Text(
                            text = groupLabel,
                            color = Color.White.copy(alpha = 0.95f),
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            maxLines = 1
                        )
                        Spacer(modifier = Modifier.height(5.dp))
                        // Saat: cam panel içinde, çok büyük
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(18.dp))
                                .background(
                                    Brush.verticalGradient(
                                        listOf(Color.White.copy(alpha = 0.30f), Color.White.copy(alpha = 0.10f))
                                    )
                                )
                                .border(
                                    1.dp,
                                    Brush.verticalGradient(
                                        listOf(Color.White.copy(alpha = 0.9f), Color.White.copy(alpha = 0.15f))
                                    ),
                                    RoundedCornerShape(18.dp)
                                )
                                .padding(horizontal = 14.dp, vertical = 4.dp)
                        ) {
                            Row(verticalAlignment = Alignment.Bottom) {
                                Text(
                                    text = "Saat",
                                    color = Color.White.copy(alpha = 0.9f),
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 15.sp,
                                    modifier = Modifier.padding(bottom = 9.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = time,
                                    color = Color.White,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 44.sp,
                                    maxLines = 1,
                                    style = TextStyle(
                                        shadow = Shadow(
                                            color = Color(0x66000000),
                                            offset = Offset(0f, 5f),
                                            blurRadius = 14f
                                        )
                                    )
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = subtitle,
                            color = Color.White.copy(alpha = 0.95f),
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp,
                            maxLines = 2
                        )
                    } else {
                        Text(
                            text = title,
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 20.sp,
                            maxLines = 2,
                            style = TextStyle(
                                shadow = Shadow(
                                    color = Color(0x55000000),
                                    offset = Offset(0f, 4f),
                                    blurRadius = 10f
                                )
                            )
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = subtitle,
                            color = Color.White.copy(alpha = 0.88f),
                            fontSize = 13.sp,
                            maxLines = 2
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Gün rozeti (cam hap)
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.White.copy(alpha = 0.34f), Color.White.copy(alpha = 0.12f))
                            )
                        )
                        .border(
                            1.dp,
                            Brush.verticalGradient(
                                listOf(Color.White.copy(alpha = 0.9f), Color.White.copy(alpha = 0.2f))
                            ),
                            RoundedCornerShape(16.dp)
                        )
                        .padding(horizontal = 12.dp, vertical = 7.dp)
                ) {
                    Text(
                        text = badge,
                        color = Color.White,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 13.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 3D parlak ilerleme çubuğu
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(18.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                // Oyuk yol
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(12.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0x40000000))
                        .border(1.dp, Color.White.copy(alpha = 0.25f), RoundedCornerShape(6.dp))
                )
                // Dolu kısım + üst parlama + yuvarlak tutamaç
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.78f)
                        .fillMaxHeight()
                ) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.CenterStart)
                            .fillMaxWidth()
                            .height(12.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(Brush.horizontalGradient(listOf(ZomoMintLight, ZomoCyan)))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(5.dp)
                                .background(
                                    Brush.verticalGradient(
                                        listOf(Color.White.copy(alpha = 0.55f), Color.Transparent)
                                    )
                                )
                        )
                    }
                    Box(
                        modifier = Modifier
                            .align(Alignment.CenterEnd)
                            .shadow(6.dp, CircleShape, ambientColor = ZomoCyan, spotColor = ZomoCyan)
                            .size(18.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.verticalGradient(listOf(Color.White, Color(0xFFD9E6FF)))
                            )
                    )
                }
            }
        }
    }
}
